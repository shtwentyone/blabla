//
//  BMICalculationViewController.swift
//  p1
//
//  Created by Llxba on 03/10/2022.
//

import UIKit

class BMICalculationViewController: UIViewController {
    
    @IBOutlet weak var Wieght: UITextField!
    
    @IBOutlet weak var Hieght: UITextField!
    
    
    @IBOutlet weak var BMI: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    //wieght = Wieght.text
    // Hieght.text = hieght;
    //BMI.text = Wieght/Hieght*Hieght
    
    @IBAction func calculation(_ sender: Any) {
        var wieght = 0.0
        var hieght  = 0.0
        if let h = Double (Hieght.text!){
            hieght = h
        }
        if let w = Double (Wieght.text!){
            wieght = w
        }
        let bmiCalc = (wieght)/(hieght*hieght)
        BMI.text=String(bmiCalc)
        
    }
    
}
