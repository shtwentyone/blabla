//
//  ViewController.swift
//  p1
//
//  Created by Llxba on 03/10/2022.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var username: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    

    @IBAction func login(_ sender: Any) {
        if username.text ==
            "Fatima"
        {performSegue(withIdentifier: "BMI1", sender: sender)}
    }
    
}

