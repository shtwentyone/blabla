//
//  ViewController.swift
//  Notification
//
//  Created by Llxba on 17/10/2022.
//

import UIKit

import NotificationCenter

class ViewController: UIViewController , UNUserNotificationCenterDelegate{
    
    var count = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let center = UNUserNotificationCenter.current()
        center.requestAuthorization(options: [.alert, .badge, .sound]) {granted, error in if let error = error {
            print(error.localizedDescription)
            
        }
            else{
                center.delegate = self
            }
        }
        
        
    }
    
    
    @IBAction func button(_ sender: Any) {
        send()
    }
    
    func send(){
        
        let content = UNMutableNotificationContent()
        content.title="Study"
        content.subtitle="Study for your next quiz"
        content.body="Study Notifications and Alerts"
        content.badge=1
        
        
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 10, repeats: false)
        
        let id = "notify1"
        let request = UNNotificationRequest(identifier: id, content: content, trigger: trigger)
        
        let center = UNUserNotificationCenter.current()
        center.add(request){error in
            if let error = error {
                print(error.localizedDescription)
            }
        }
    
    }
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        completionHandler([.banner,.sound])
    }
}
