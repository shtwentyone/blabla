

//This lab like UserDefults lab but wwe will add somethings more in it


import UIKit

class ViewController: UIViewController {

    
    @IBOutlet var text: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    
    @IBAction func saveButton(_ sender: Any) {
        
        let str = text.text!
        let fileName = getDirecory().appendingPathComponent("output.txt")
        
        do {
            try str.write(to: fileName, atomically: true, encoding: String.Encoding.utf8)
            print("Writing to the file has successful")
        }
        catch{
            print("Writing to the file has faild")
        }
    }
    
    
    
    
    @IBAction func readButton(_ sender: Any) {

        let fileName = getDirecory().appendingPathComponent("output.txt")
        
        do {
            let content = try String(contentsOf: fileName)
            text.text = content
        }
        catch{
            print("Reading  the file has faild")
        }
    }
    
    
    func getDirecory()->URL{
        let path = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        
        return path [0]
        
    }


}

