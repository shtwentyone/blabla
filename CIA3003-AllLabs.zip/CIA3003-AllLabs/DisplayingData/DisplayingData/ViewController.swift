//
//  ViewController.swift
//  DisplayingData
//
//  Created by Llxba on 26/09/2022.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

