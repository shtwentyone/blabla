//
//  Item.swift
//  ShoppingList
//
//  Created by Llxba on 07/11/2022.
//

import Foundation

struct item{
    
    var id:UUID = UUID()
    var itemName: String
    var itemDate: String
    var itemDesc: String
    var itemType: String
    
}
