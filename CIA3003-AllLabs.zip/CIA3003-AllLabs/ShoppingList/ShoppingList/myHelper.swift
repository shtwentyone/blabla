//
//  myHelper.swift
//  ShoppingList
//
//  Created by Llxba on 07/11/2022.
//

import Foundation
import CoreData
import UIKit

class myHelper{
    //get access to the manged object context
    let managedObjectContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    //***************************************************************************
    //Create the first function to add the item to the items table
    //this function recived  the item object
    func addItem(item : Item){
        //get the item desc
        let entity = NSEntityDescription.entity( forEntityName: "item", in: managedObjectContext)
        //Create the record to be insterted to the database
        let itemRecord = NSManagedObject(entity: entity!, insertInto: managedObjectContext)
        //update all the fields
        itemRecord.setValue(item.id, forKeyPath: "id")
        itemRecord.setValue(item.itemName, forKeyPath: "itemName")
        itemRecord.setValue(item.itemType, forKeyPath: "itemType")
        itemRecord.setValue(item.itemDesc, forKeyPath: "itemDesc")
        itemRecord.setValue(item.itemDate, forKeyPath: "itemDate")
        //save the managed object
        do{
            try
            managedObjectContext.save()
            print("Record Save")}
        catch
            let error as NSError{
            print("Colud not save the record")
        }
        //***************************************************************************
        //Ctreate function to find item by name in the database
        //this function recived  the item object
        func findItemByName(name: String)-> item? //? mean it is Optional
        {
            var foundItem : item?
            //select * from item where name == "DFDFD"
            //Create the predicate like the select operation of SQL
            let search = NSPredicate(format: "itemName == %@", name)
            //Cteate the fetch request
            let query = NSFetchRequest <NSManagedObject>(entityName: "Item")
            //call the query from the predicate and it's lelated to the name
            //IN THE OTHER SAY
            //set the predicate to the query
            query.predicate = search
            //run the query and check the output
            do{
                let results = try managedObjectContext.fetch(query)
                if results.count > 0 {
                    let row = results[0]
                    let id = row.value(forKeyPath: "id") as? UUID
                    let itemName = row.value(forKeyPath: "itemName") as? String
                    let itemType = row.value(forKeyPath: "itemType") as? String
                    let itemDesc = row.value(forKeyPath: "itemDesc") as? String
                    let itemDate = row.value(forKeyPath: "itemDate") as? String
               
                    foundItem = item(id: "id", itemName: "name", itemDate: "date", itemDesc: "desc", itemType: "type")
                     
                }
                else {
                    print("No Record Found ")
                }
            }
                catch
                    let error as NSError{
                    print("Colud find the record")
                }
                return foundItem
        }
    }
    //***************************************************************************
    //Ctreate function to delete item by name in the database
    //this function recived  the item object
    func deleteItemByName(name: String){
        let search = NSPredicate(format: "itemName == %@", name)
        let query = NSFetchRequest<NSManagedObject>(entityName: "Item")
        query.predicate = search
        do{
            let results = try managedObjectContext.fetch(query)
            if results.count > 0{
                let row = results[0]
                managedObjectContext.delete(row)
                try managedObjectContext.save()
            }
            else{
                print("No record found")
            }
            
          }
        catch
            let error as NSError{
            print("Cloud not save the record \(error.localizedDescription)")
            }
    }
    //***************************************************************************
    //Ctreate function to get all the item from the database
    //this function load item in the table view
    func getAllItems()-> [item]{
        var items = [item]()
        let query = NSFetchRequest<NSManagedObject>(entityName: "Item")
        do{
            let results = try managedObjectContext.fetch(query)
            for row in results{
                let id = row.value(forKeyPath: "id") as? UUID
                let itemName = row.value(forKeyPath: "itemName") as? String
                let itemType = row.value(forKeyPath: "itemType") as? String
                let itemDesc = row.value(forKeyPath: "itemDesc") as? String
                let itemDate = row.value(forKeyPath: "itemDate") as? String
                let item = item (itemName: "itemName", itemDate: "itemDate", itemDesc: "itemDesc", itemType: "itemType")
                items.append(item)
            }
        }
            catch
                let error as NSError{
                print("cloud not save the record \(error.localizedDescription)")
            }
            return items
        }
    }
    
