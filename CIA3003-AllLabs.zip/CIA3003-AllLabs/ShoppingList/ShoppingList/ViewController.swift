//
//  ViewController.swift
//  ShoppingList
//
//  Created by Llxba on 07/11/2022.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet var txtUser: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func Active(_ sender: Any) {
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "additem"{
            let vc = segue.destination as! ItemViewController
            vc.userName = txtUser.text!
            
        }
    }
    

}

