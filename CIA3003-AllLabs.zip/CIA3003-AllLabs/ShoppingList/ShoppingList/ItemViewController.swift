//
//  ItemViewController.swift
//  ShoppingList
//
//  Created by Llxba on 14/11/2022.
//

import UIKit

class ItemViewController: UIViewController {

    var userName = " "
    
    let helper = myHelper()
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    


}
