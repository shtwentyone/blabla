//
//  ViewController.swift
//  Unit1
//
//  Created by Llxba on 21/09/2022.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var mainLabel: UILabel!
    
    @IBOutlet weak var changeTitle: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func changetitle2(_ sender: Any) {
        mainLabel.text="This app rocks!"
    }
    
}

