//
//  ViewController.swift
//  View
//
//  Created by Llxba on 28/09/2022.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var label: UILabel!
    
    @IBOutlet weak var mytext: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "Try"
        {let nextvc = segue.destination as! SecondViewController
            nextvc.name = mytext.text!
        }
        
        
        
    }


}

