import UIKit
//We needs to import notification
import NotificationCenter

class ViewController: UIViewController, UNUserNotificationCenterDelegate {

    @IBOutlet var button: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Create notification center
        let center = UNUserNotificationCenter.current()
        center.requestAuthorization(options: [.alert, .badge, .sound]) {granted, error in
            if let error = error {
                print(error.localizedDescription)
            }
            else{
                center.delegate = self // self mean in this ViewController page
            }
        }
    }
    
    @IBAction func send(_ sender: UIButton) {
        send()
    }
    
    // Create the send function
    func send(){
        // Create the content
        let content = UNMutableNotificationContent()
        // Differet attrubite for this content
        content.title = "Registration Successful"
        content.subtitle = "Congralulation for using this app "
        content.body = "This is to notify you that have registerd successfly in this app"
        content.badge = 1 // number of notify in app
        // Set thee trigger for the notification center when you send the notification
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 5, repeats: false) //timeInterval it's the time until the notification show for us
        // Create the request for the notification
        let id = "Notif1"
        let request = UNNotificationRequest(identifier: id, content: content ,trigger: trigger)
        // Add the request to the notification center
        let center = UNUserNotificationCenter.current()
        center.add(request){error in
            if let error = error {
                print(error.localizedDescription)
            }
        }
        
    }
    //If we don't add this function it will show the notification in the backgroud only
    // In this function we will show the notification in the same page(delegate class)
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        completionHandler([.banner,.sound])
    }
    
    
}

