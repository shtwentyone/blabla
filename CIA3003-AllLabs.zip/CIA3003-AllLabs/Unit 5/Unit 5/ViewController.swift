//
//  ViewController.swift
//  Unit 5
//
//  Created by Llxba on 19/09/2022.
//

import UIKit

class ViewController: UIViewController {

   
    @IBOutlet weak var txtName: UITextField!
    
  
    @IBOutlet weak var button: UIButton!
    
   
    @IBOutlet weak var lblNmame: UILabel!
    
    override func viewDidLoad() { //this first function that run with the application.
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func Click(_ sender: UIButton) {
        lblNmame.text="Hello, " + txtName.text!
    }
    
    
    


}

