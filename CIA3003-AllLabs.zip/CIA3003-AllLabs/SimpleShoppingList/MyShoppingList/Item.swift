//
//  Item.swift
//  MyShoppingList
//
//  Created by AFARHAT on 11/14/21.
//

import Foundation

// A structure that represents th table Items in the database.

struct Item{
    
    var  id:UUID = UUID()
    var  itemName : String
    var  itemDesc : String
    var  itemType : String
    
}
