//
//  MyHelper.swift
//  MyShoppingList
//
//  Created by AFARHAT on 11/14/21.
//

import  UIKit
import CoreData

class MyHelper
{
    //Get access to the managed object context
    let managedObjectContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    // ************************************************************************
    // Create funciton that add  an item to the Items table
    // This function receives the an Item object
    // ************************************************************************
    func addItem(item: Item)
    {
        
        let entity = NSEntityDescription.entity(forEntityName: "Items", in: managedObjectContext)
        
        // Create record to be inserted into the database
        let itemRecord = NSManagedObject(entity: entity!, insertInto: managedObjectContext)
        
        // Update all fields
        itemRecord.setValue(item.id, forKeyPath: "id")
        itemRecord.setValue(item.itemName, forKeyPath: "itemName")
        itemRecord.setValue(item.itemDesc, forKeyPath: "itemDesc")
        itemRecord.setValue(item.itemType, forKeyPath: "itemType")
        
        // Save the managed object
        do {
            try managedObjectContext.save()
            print("Record is Saved")
            
        } catch let error as NSError {
            
            print("Could not save the record \(error.localizedDescription)")
        }
        
    }

   // ************************************************************************
   // Create funciton that finds an item usign the name of the item
   // This function returns an Item object
   // ************************************************************************
    func findItemByName(name:String) -> Item?
    {
        var foundItem : Item?
        // Create a predicate similar to the where clause in SQL
        let search = NSPredicate(format: "itemName == %@", name  )
        // Create the Fetch requst similar to the select statment in SQL
        let query = NSFetchRequest<NSManagedObject>(entityName: "Items")
        // set the predicate for the query
        query.predicate = search
        
        // Run the query and check the result
        do {
            let results = try managedObjectContext.fetch(query)
            if results.count > 0
            {
                let row = results[0]
                let itemId =   row.value(forKeyPath:"id") as? UUID
                let itemName = row.value(forKeyPath:"itemName") as? String
                let itemDesc = row.value(forKeyPath: "itemDesc") as? String
                let itemType = row.value(forKeyPath: "itemType") as? String
                foundItem = Item(id: itemId!, itemName: itemName!, itemDesc: itemDesc!, itemType: itemType!)
       
            } else
            {
                print("No Records Found")
            }
        }catch let error as NSError
        {
            print("Could not save the record \(error.localizedDescription)")
        }
        
        return foundItem
        
    }
    
   // ************************************************************************
   // Create a funciton that finds an item usign the name of the item
   // and delete that item from the Items table
   // ************************************************************************
    func deleteItemByName(name:String)
    {
        let search = NSPredicate(format: "itemName == %@", name  )
        let query = NSFetchRequest<NSManagedObject>(entityName: "Items")
        query.predicate = search
        
        do {
            let results = try managedObjectContext.fetch(query)
            if results.count > 0
            {
                let row = results[0]
                managedObjectContext.delete(row)
                try managedObjectContext.save()
                
            } else
            {
                print("No Records Found")
            }
        }catch let error as NSError
        {
            print("Could not save the record \(error.localizedDescription)")
        }
    }
   
    // ************************************************************************
    // Create a funciton that gets all items from the Items table
    // and return and array of Item objects
    // ************************************************************************
    func getAllItems()->[Item]
    {
         var items = [Item]()
     
        let query = NSFetchRequest<NSManagedObject>(entityName: "Items")
        
         do {
             let results = try managedObjectContext.fetch(query)
             for row in results
             {
                    let itemId =   row.value(forKeyPath:"id") as? UUID
                    let itemName = row.value(forKeyPath:"itemName") as? String
                    let itemDesc = row.value(forKeyPath: "itemDesc") as? String
                    let itemType = row .value(forKeyPath: "itemType") as? String
                    let item = Item(id: itemId!, itemName: itemName!, itemDesc: itemDesc!, itemType: itemType!)
                    items.append(item)
             }
                
         }catch let error as NSError
         {
             print("Could not save the record \(error.localizedDescription)")
         }
        return items
    }
 
    
}
