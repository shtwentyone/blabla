//
//  DetailsViewController.swift
//  MyShoppingList
//
//  Created by AFARHAT on 11/17/21.
//

import UIKit

class DetailsViewController: UIViewController {
   
    let helper = MyHelper()
    
    var itemName = ""
    
    @IBOutlet weak var lblDesc: UILabel!
    @IBOutlet weak var lblType: UILabel!
    @IBOutlet weak var lblName: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let item = helper.findItemByName(name: itemName)
        
        if item != nil
        {
            lblName.text = item?.itemName
            lblDesc.text = item?.itemDesc
            lblType.text = item?.itemType
            
            
        }

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func btnCancel(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
}
