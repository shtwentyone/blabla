//
//  ViewController.swift
//  MyShoppingList
//
//  Created by AFARHAT on 11/14/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtUser: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "addItem" {
            let vc = segue.destination as! ItemViewController
            vc.userName = txtUser.text!
        }
        }
        

}

