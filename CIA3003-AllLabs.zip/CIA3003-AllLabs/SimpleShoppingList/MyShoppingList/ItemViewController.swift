//
//  ItemViewController.swift
//  MyShoppingList
//
//  Created by AFARHAT on 11/14/21.
//

import UIKit

class ItemViewController: UIViewController {

    var userName = ""
    
    // Create an object of my Helper class
    let helper = MyHelper()
    
    @IBOutlet weak var lblGreetign: UILabel!
    @IBOutlet weak var txtType: UITextField!
    @IBOutlet weak var txtDesc: UITextField!
    @IBOutlet weak var txtName: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        lblGreetign.text = "Hello " + userName
        
        
        let allRecords = helper.getAllItems()
        print(allRecords)
         
        // Do any additional setup after loading the view.
    }

   
    @IBAction func btnAdd(_ sender: Any) {
        
        // Get all the fields from the screen and validate data
        
        // below is a sample validation
        
        var msg = ""
        
        if txtName.text!.isEmpty {
            msg = "Item name cannot be empty"
        }
    
        
        if msg.isEmpty {
        // Create the object item and call the fundtion in My Helper Class.
        
            let name = txtName.text!
            let desc = txtDesc.text!
            let type = txtType.text!
        
            let newItem = Item(itemName: name , itemDesc: desc, itemType: type)
            helper.addItem(item: newItem)
        } else {
            
            Alert.show("Error", message: msg, vc: self)
        }
        
    }
    
    @IBAction func btnFind(_ sender: Any) {
        
        let name = txtName.text!
        let item = helper.findItemByName(name: name)
        if  item != nil
        {
            txtName.text = item!.itemName
            txtDesc.text = item!.itemDesc
            txtType.text = item!.itemType
        } else
        {
            Alert.show("Warning", message: "No Record is Found", vc: self)
        }
        
        
     }
    
    @IBAction func btnCancel(_ sender: Any) {
        
        // dismiss the curren view controller
        self.dismiss(animated: true, completion: nil)
    }
    
}
