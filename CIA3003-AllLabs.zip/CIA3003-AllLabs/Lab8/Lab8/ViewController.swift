//
//  ViewController.swift
//  Lab8
//
//  Created by Llxba on 17/10/2022.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet var UNlabel: UILabel!
    
    @IBOutlet var UNtext: UITextField!
    
    
    @IBOutlet var Plabel: UILabel!
    
    @IBOutlet var Ptext: UITextField!
    
    
    @IBOutlet var button: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func buttonAction(_ sender: Any) {
        
        var msg = ""
        
        if UNtext.text!.isEmpty{
            msg = "User Name cannot be blank\n"
        }
        if Ptext.text!.count<8 {
            msg += "Password must be 8 character long"
        }
        if !msg.isEmpty{
            showAlert("Error", massage: msg)
        }
        else {
            saveUser()
            showAlert("Success", massage: "Welcome to our Amazing App")
        }
    }
    
    func showAlert(_ title:String, massage:String){
        let alertController = UIAlertController(title: "Greetings", message: "Enter Your Name ", preferredStyle: UIAlertController.Style.alert)
        let alartCT = UIAlertController(title: title, message: massage, preferredStyle: UIAlertController.Style.alert)
        let okAc = UIAlertAction(title: "OK", style: UIAlertAction.Style.default) { UIAlertAction in
            alertController.dismiss(animated: true, completion: nil)
        }
        alartCT.addAction(okAc)
        present(alartCT, animated: true, completion: nil)
    }
    func saveUser(){
        
    }
}

