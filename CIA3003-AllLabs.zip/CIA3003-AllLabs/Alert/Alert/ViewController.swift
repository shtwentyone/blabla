//
//  ViewController.swift
//  Alert
//
//  Created by Llxba on 17/10/2022.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet var label: UILabel!
    
    
    @IBOutlet var button: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func buttonAction(_ sender: UIButton) {
        
        //1. Create alert controller
        let alertController = UIAlertController(title: "Greetings", message: "Enter Your Name ", preferredStyle: UIAlertController.Style.alert)
        
        //2. Add textField
        alertController.addTextField(configurationHandler: {
            (textField1: UITextField ) in textField1.placeholder = "Enter Your Name "})// placeholder to display in the text filed
        alertController.addTextField(configurationHandler: {
            (textField2: UITextField ) in textField2.placeholder = "Enter Your Password "
            textField2.isSecureTextEntry = true})//This line to be hide
        
        //3. Create alert action
            //First Action
        let okAc = UIAlertAction(title: "OK", style: UIAlertAction.Style.default) { UIAlertAction in
            alertController.dismiss(animated: true, completion: nil)
        let name = alertController.textFields![0]
            self.label.text  = name.text
        }
            //Second Action
        let cancelAc = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.default) { UIAlertAction in
            alertController.dismiss(animated: true, completion: nil)
        }
        
        //4. Add the Action to the alert controller
        alertController.addAction(okAc)
        alertController.addAction(cancelAc)
        
        //5. Display the alert controller
        //if it's not work we can add the self before the present
        present(alertController, animated: true, completion: nil)
    }
    
    
}

