//
//  Contacts.swift
//  TableView
//
//  Created by Llxba on 31/10/2022.
//

import Foundation
//Create a struct
struct Contact {
    //create tree type
    var name: String
    var details: String
    var image : String
    //We will take it from the arrays
    static func getContacts () -> [Contact]{
        //return the value 
        return [
            Contact (name: "Fatime", details: "Good Morning", image: "avatar"),
            Contact (name: "Aisha", details: "Good Evening", image: "avatar"),
            Contact (name: "Amna", details: "Good Afternoon", image: "avatar"),
            Contact (name: "Sara", details: "Hi", image: "avatar"),
            Contact (name: "Maryam", details: "Hello", image: "avatar")
        ]
    }
}
