//
//  ViewController.swift
//  Title
//
//  Created by Llxba on 05/10/2022.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var user: UITextField!
    @IBOutlet var Pass: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    override func prepare (for segue: UIStoryboardSegue, sender: Any?){
            segue.destination.navigationItem.title=user.text
        }
        
    @IBAction func username(_ sender: Any) {
        performSegue(withIdentifier: "landingsegue", sender: user)
    }
    
    @IBAction func Password(_ sender: Any) {
        performSegue(withIdentifier: "landingsegue", sender: Pass)
    }
    
}
