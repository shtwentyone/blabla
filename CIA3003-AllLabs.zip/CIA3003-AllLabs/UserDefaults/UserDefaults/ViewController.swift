//
//  ViewController.swift
//  UserDefaults
//
//  Created by Llxba on 24/10/2022.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet var text: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func saveButton(_ sender: Any) {
        
        let defaults = UserDefaults.standard
        let name = text.text!
        let key = "UserName"
        
        defaults.set(name, forKey: key)
        
    }
    
    
    @IBAction func readButton(_ sender: Any) {
        
        let defaults = UserDefaults.standard
        let key = "UserName"
        
        if defaults.object(forKey: key) == nil {
            // nil mean we can't find it
            print("User is not saved")
        }
        else {
            let user = defaults.string(forKey: key)
            text.text = user 
        }
    }
    
    
}

