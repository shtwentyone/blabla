import UIKit

var greeting =  "Hello, playground"

let defaultScore = 100
var userOneScore = defaultScore
var userTwoScore = defaultScore

//first way
print("The user score one is \(userOneScore)")
//second way
print (userOneScore)

/* we can't change the default only the user score.
 for example:
              defaultScore = 200*/

userTwoScore=200
print(userTwoScore)

//STRUCT
struct Person{
    let firstName : String
    let secondName : String
    
    func sayHello(){
        print ("Hello there! My name is \(firstName) \(secondName).")
    }
}

let aPerson = Person(firstName: "Alia" , secondName: "Khaled")
let otherPerson = Person(firstName: "Sara" , secondName: "Ali")

print()

aPerson.sayHello()
otherPerson.sayHello()

//Type Safety
let limit = 30.0
var age = 40
var height = 170.5

//I can type the double like this But I can't type the int like this
let limit1:Double = 30

/* here when we type a int will give us a error
    let limit2:Int = 30.1 */

//If we type like this it will be work
let limit2:Int = 30

/* We can't = two value if the datatype is different
 for example:
            height = age
 that is not allowed because it is double and int */


// we can do it like this because both of them are double
height = limit

print()
print(height)

/*we can't print this because there is no value here
 for example:
            var age1:Int
            print(age1)
*/

