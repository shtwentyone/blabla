import UIKit

var greeting = "Hello, playground"
let name = "Bashayer"
print(name)
print("Welcome to CIA 3003 \(name)")
let lastname="Ali"
print("Hello \(name) \(lastname)")
