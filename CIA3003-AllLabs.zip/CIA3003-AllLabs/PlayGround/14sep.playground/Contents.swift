import UIKit

var greeting = "Hello, playground"
let x=23.5
let y=3.0 //if we type it only 3 It will give us an error becouse it will be a int and double
//we can type 3 like let y:Double=3 or in print we can type it like print(Double(y)+x)
print(x+y)

var q = 3
let w=3
q+=4
print(q)

let num = 1000
let smallNumber = num < 10
print (smallNumber)
 

print("")
let tem = 70
switch tem {
case Int.min ... 65:
    print ("cold")
case 65...75:
    print("just right")
default:
    print("hot")
}
