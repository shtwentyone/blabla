//
//  ViewController.swift
//  Light
//
//  Created by Llxba on 21/09/2022.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var buttonPressed: UIButton!
    
    var lightOn = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    fileprivate func updateUI() {
        if lightOn {
            view.backgroundColor = .lightGray
        }
        
    }
    
    @IBAction func button(_ sender: Any) {
        lightOn.toggle()
        updateUI()
    }
    
}

